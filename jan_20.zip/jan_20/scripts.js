/* let chosenNumber = Match.floor(Math.random() * 10);

switch (chosenNumber) {
    case 1:
        console.log('One');
        break;
    case 2:
        console.log('Two');
        break;
    case 3:
        console.log('Three');
        break;
    case 4:
        console.log('Four');
        break;
    case 5:
        console.log('Five');
        break;
    case 6:
        console.log('Six');
        break;
    default:
        console.log("I don't know");
        break;
} */




/* console.log('some text here');

const message = 'Hello world from constant variable message';

console.log(message);

let emptyMessage = 'New message in let variable';

console.log(emtyMessage);
 */